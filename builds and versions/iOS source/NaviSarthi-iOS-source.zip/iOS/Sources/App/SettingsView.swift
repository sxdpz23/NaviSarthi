import SwiftUI
import UIKit
import SwiftData
import UniformTypeIdentifiers
import CryptoKit

struct SettingsView: View {
    @EnvironmentObject private var settings: Settings
    @EnvironmentObject private var nav: NavigationSession
    @EnvironmentObject private var dash: DashConnection
    @EnvironmentObject private var pod: PodConnection
    var body: some View {
        NavigationStack {
            Form {
                Section("Console") {
                    Picker("Selected console",selection:$settings.target) { ForEach(ConsoleTarget.allCases) { Text($0.rawValue).tag($0) } }
                        .disabled(nav.active)
                    if nav.active { Text("End navigation before changing console.").font(.caption) }
                }
                Section("Navigation") {
                    NavigationLink("Routing provider",destination:RoutingSettingsView())
                    Toggle("Voice instructions",isOn:$settings.voice)
                    Toggle("Miles",isOn:$settings.miles)
                    Toggle("Traffic on phone map",isOn:$settings.traffic)
                    Picker("Route colour",selection:$settings.routeColour) { ForEach(["Blue","Vehicle","Gold"],id:\.self) { Text($0) } }
                    Text("Apple Maps works without a key. Configure Mapbox for traffic-coloured routes or your Valhalla endpoint for motorcycle costing. Saved routes support offline guidance; offline road-network calculation still needs the native engine.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Your data") {
                    NavigationLink("Ride history",destination:RidesView())
                    NavigationLink("Backup and restore",destination:BackupView())
                    NavigationLink("Cloud account and backup",destination:CloudBackupView())
                    Text("Garage, documents, expenses, saved routes and rides are stored locally. Backups never include account passwords or Comms credentials.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("iPhone permissions") {
                    Button("Open iPhone Settings",systemImage:"arrow.up.forward.app") {
                        if let url = URL(string:UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                    }
                    Text("Location is used for navigation and recording. Bluetooth connects the Pod. Local Network and Hotspot Configuration connect the Dash.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Port status") {
                    LabeledContent("Version",value:"0.7.1 · iOS development")
                    Text("Source project prepared on Windows; Xcode compilation, simulator tests, signing and bike validation are pending.")
                    Text("Dash video stops when backgrounded. Structured turn glyphs are available with Mapbox or Valhalla; Apple Maps uses unknown glyphs. Other apps’ music and phone-call access does not have Android-equivalent support.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Link("Apple background execution documentation",destination:URL(string:"https://developer.apple.com/documentation/uikit/about-the-background-execution-sequence")!)
                }
                Section {
                    Text("Independent project. Not affiliated with or endorsed by Royal Enfield. Compatibility names belong to their respective owners.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }.navigationTitle("Settings")
        }
    }
}

struct RoutingSettingsView: View {
    @AppStorage("routingProvider") private var provider = "Apple Maps"
    @AppStorage("valhallaEndpoint") private var endpoint = ""
    @State private var token = ""
    @State private var status = ""
    var body: some View {
        Form {
            Picker("Provider",selection:$provider) { ForEach(["Apple Maps","Mapbox traffic","Valhalla motorcycle"],id:\.self) { Text($0) } }
            Section("Mapbox") {
                SecureField("Public access token",text:$token).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Save token securely") { do { if token.isEmpty { KeychainStore.remove("mapboxToken") } else { try KeychainStore.write(Data(token.utf8),key:"mapboxToken") }; status = "Token updated" } catch { status = error.localizedDescription } }
            }
            Section("Your Valhalla server") {
                TextField("HTTPS route endpoint",text:$endpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                Text("Use your server's complete /route URL. The motorcycle costing model must be enabled on that server.").font(.caption)
            }
            Text("Requests send your route points to the selected provider. Mapbox usage is billed to your token. Provider settings take effect on the next route calculation.").font(.footnote).foregroundStyle(.secondary)
            if !status.isEmpty { Text(status) }
        }.navigationTitle("Routing provider").onAppear { token = KeychainStore.read("mapboxToken").flatMap { String(data:$0,encoding:.utf8) } ?? "" }
    }
}

struct BackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(data:Data = Data()) { self.data = data }
    init(configuration:ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration:WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents:data) }
}
struct BackupView: View {
    @Environment(\.modelContext) private var context
    @State private var exporting = false
    @State private var importing = false
    @State private var document = BackupDocument()
    @State private var pending: LocalBackup?
    @State private var confirm = false
    @State private var status = ""
    var body: some View {
        Form {
            Section("Local backup") {
                Button("Export all local data",systemImage:"square.and.arrow.up") {
                    do { try context.save(); document = BackupDocument(data:try JSONEncoder().encode(LocalBackup.capture(context))); exporting = true }
                    catch { status = error.localizedDescription }
                }
                Button("Import backup",systemImage:"square.and.arrow.down") { importing = true }
                Text("Includes documents and invoices. Keep the exported file private. Import adds missing records and preserves existing IDs and edits.").font(.footnote).foregroundStyle(.secondary)
            }
            if !status.isEmpty { Text(status) }
        }.navigationTitle("Backup and restore")
            .fileExporter(isPresented:$exporting,document:document,contentType:.json,defaultFilename:"NaviSarthi-backup.json") { result in
                if case .failure(let error) = result { status = error.localizedDescription }
            }
            .fileImporter(isPresented:$importing,allowedContentTypes:[.json]) { result in
                do {
                    let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let size = try url.resourceValues(forKeys:[.fileSizeKey]).fileSize ?? 0
                    guard size <= 100_000_000 else { throw WireClientError("Backup exceeds 100 MB") }
                    pending = try LocalBackup.read(Data(contentsOf:url)); confirm = true
                } catch { status = error.localizedDescription }
            }
            .confirmationDialog("Import \(pending?.rows.count ?? 0) backup records?",isPresented:$confirm,titleVisibility:.visible) {
                Button("Import missing records") {
                    do { if let pending { status = "Imported \(try pending.restore(into:context.container)) new records." } }
                    catch { status = error.localizedDescription }; pending = nil
                }
                Button("Cancel",role:.cancel) { pending = nil }
            }
    }
}

struct FirebaseLogin: Codable {
    var uid: String; var idToken: String; var refreshToken: String; var expires: Date
}
@MainActor final class CloudBackupClient: ObservableObject {
    @Published var signedIn = false
    @Published var busy = false
    @Published var status = ""
    @Published var project = UserDefaults.standard.string(forKey:"firebaseProject") ?? ""
    @Published var apiKey = UserDefaults.standard.string(forKey:"firebasePublicKey") ?? ""
    private var login: FirebaseLogin?
    private let session: URLSession
    init() {
        let config = URLSessionConfiguration.ephemeral; config.timeoutIntervalForRequest = 30
        session = URLSession(configuration:config,delegate:NoRedirects(),delegateQueue:nil)
        if let data = KeychainStore.read("firebaseLogin"), let value = try? JSONDecoder().decode(FirebaseLogin.self,from:data) { login = value; signedIn = true }
    }
    func signIn(email:String,password:String,create:Bool = false) async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do {
            try validateConfiguration()
            let url = try authURL(host:"identitytoolkit.googleapis.com",path:"/v1/accounts:\(create ? "signUp" : "signInWithPassword")")
            let data = try await call(url,method:"POST",body:["email":email,"password":password,"returnSecureToken":true])
            struct Response: Decodable { var localId:String; var idToken:String; var refreshToken:String; var expiresIn:String }
            let result = try JSONDecoder().decode(Response.self,from:data)
            guard !result.localId.contains("/"), !result.localId.isEmpty else { throw WireClientError("Unsupported account ID") }
            let login = FirebaseLogin(uid:result.localId,idToken:result.idToken,refreshToken:result.refreshToken,expires:Date().addingTimeInterval(Double(result.expiresIn) ?? 3600))
            try save(login); signedIn = true; status = "Signed in. Cloud backup is explicit; no data uploaded yet."
            UserDefaults.standard.set(project,forKey:"firebaseProject"); UserDefaults.standard.set(apiKey,forKey:"firebasePublicKey")
        } catch { status = error.localizedDescription }
    }
    func resetPassword(email:String) async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do { try validateConfiguration(); _ = try await call(authURL(host:"identitytoolkit.googleapis.com",path:"/v1/accounts:sendOobCode"),method:"POST",body:["requestType":"PASSWORD_RESET","email":email]); status = "If the account exists, a reset email will be sent." }
        catch { status = error.localizedDescription }
    }
    func signOut() { login = nil; signedIn = false; KeychainStore.remove("firebaseLogin"); status = "Signed out" }
    private func validateConfiguration() throws {
        guard (6...63).contains(project.count), project.utf8.allSatisfy({ (97...122).contains($0) || (48...57).contains($0) || $0 == 45 }), !apiKey.isEmpty else { throw WireClientError("Enter your Firebase project ID and public Web API key") }
    }
    private func authURL(host:String,path:String) throws -> URL {
        var parts = URLComponents(); parts.scheme = "https"; parts.host = host; parts.path = path; parts.queryItems = [URLQueryItem(name:"key",value:apiKey)]
        guard let url = parts.url else { throw URLError(.badURL) }; return url
    }
    private func save(_ value: FirebaseLogin) throws { try KeychainStore.write(JSONEncoder().encode(value),key:"firebaseLogin"); login = value }
    private func token() async throws -> FirebaseLogin {
        guard let login else { throw WireClientError("Sign in first") }
        if login.expires.timeIntervalSinceNow > 60 { return login }
        let data = try await call(authURL(host:"securetoken.googleapis.com",path:"/v1/token"),method:"POST",body:["grant_type":"refresh_token","refresh_token":login.refreshToken])
        struct Refresh:Decodable { var id_token:String; var refresh_token:String; var expires_in:String; var user_id:String }
        let response = try JSONDecoder().decode(Refresh.self,from:data)
        guard response.user_id == login.uid else { throw WireClientError("Account changed; sign in again") }
        let renewed = FirebaseLogin(uid:login.uid,idToken:response.id_token,refreshToken:response.refresh_token,expires:Date().addingTimeInterval(Double(response.expires_in) ?? 3600))
        try save(renewed); return renewed
    }
    private var documentsPath: String { "projects/\(project)/databases/(default)/documents" }
    private func cloudURL(_ path:String) -> URL { URL(string:"https://firestore.googleapis.com/v1/\(documentsPath)/\(path)")! }
    func upload(_ backup:LocalBackup) async {
        guard !busy else { return }; busy = true; defer { busy = false }
        do {
            let auth = try await token(), data = try JSONEncoder().encode(backup)
            guard data.count <= 4_000_000 else { throw WireClientError("Cloud backups are limited to 4 MB. Use local file export for larger backups with attachments.") }
            let latest = "users/\(auth.uid)/iosState/latest"
            let previous = try await getDocument(latest,token:auth.idToken,allowMissing:true)
            let generation = UUID().uuidString
            let count = (data.count + 299999) / 300000
            var writes: [[String:Any]] = []
            for index in 0..<count {
                let chunk = data.subdata(in:(index * 300000)..<min(data.count,(index + 1) * 300000))
                let name = "\(documentsPath)/users/\(auth.uid)/iosBackups/\(generation)-\(index)"
                writes.append(["update":["name":name,"fields":["data":["bytesValue":chunk.base64EncodedString()]]],"currentDocument":["exists":false]])
            }
            let checksum = SHA256.hash(data:data).map { String(format:"%02x",$0) }.joined()
            let fields: [String:Any] = ["generation":["stringValue":generation],"chunks":["integerValue":String(count)],"sha256":["stringValue":checksum],"createdAt":["timestampValue":ISO8601DateFormatter().string(from:Date())]]
            let precondition: [String:Any]
            if let time = previous?["updateTime"] as? String { precondition = ["updateTime":time] }
            else { precondition = ["exists":false] }
            writes.append(["update":["name":"\(documentsPath)/\(latest)","fields":fields],"currentDocument":precondition])
            _ = try await call(URL(string:"https://firestore.googleapis.com/v1/\(documentsPath):commit")!,method:"POST",body:["writes":writes],bearer:auth.idToken)
            status = "Cloud backup uploaded atomically. Older backup chunks are retained; manage storage in Firebase."
        } catch { status = error.localizedDescription }
    }
    func download() async throws -> LocalBackup {
        guard !busy else { throw WireClientError("Another cloud operation is in progress") }; busy = true; defer { busy = false }
        let auth = try await token()
        guard let document = try await getDocument("users/\(auth.uid)/iosState/latest",token:auth.idToken), let fields = document["fields"] as? [String:Any], let generation = (fields["generation"] as? [String:Any])?["stringValue"] as? String,
              UUID(uuidString:generation) != nil, let countText = (fields["chunks"] as? [String:Any])?["integerValue"] as? String, let count = Int(countText), (1...14).contains(count), let checksum = (fields["sha256"] as? [String:Any])?["stringValue"] as? String else { throw WireClientError("Invalid cloud backup manifest") }
        var bytes = Data()
        for index in 0..<count {
            guard let chunk = try await getDocument("users/\(auth.uid)/iosBackups/\(generation)-\(index)",token:auth.idToken), let fields = chunk["fields"] as? [String:Any], let text = (fields["data"] as? [String:Any])?["bytesValue"] as? String, let data = Data(base64Encoded:text), data.count <= 300000 else { throw WireClientError("Missing cloud backup chunk") }
            bytes.append(data)
        }
        guard SHA256.hash(data:bytes).map({ String(format:"%02x",$0) }).joined() == checksum else { throw WireClientError("Cloud backup checksum mismatch") }
        return try LocalBackup.read(bytes)
    }
    private func getDocument(_ path:String,token:String,allowMissing:Bool = false) async throws -> [String:Any]? {
        do { return try JSONSerialization.jsonObject(with:await call(cloudURL(path),method:"GET",bearer:token)) as? [String:Any] }
        catch let error as WireClientError { if allowMissing && error.message.hasPrefix("HTTP 404") { return nil }; throw error }
    }
    private func call(_ url:URL,method:String,body:[String:Any]? = nil,bearer:String? = nil) async throws -> Data {
        var request = URLRequest(url:url); request.httpMethod = method
        if let body {
            if url.host == "securetoken.googleapis.com" {
                let encoded = body.map { key,value in
                    (key.addingPercentEncoding(withAllowedCharacters:.alphanumerics) ?? "") + "=" + (String(describing:value).addingPercentEncoding(withAllowedCharacters:.alphanumerics) ?? "")
                }.joined(separator:"&")
                request.httpBody = Data(encoded.utf8); request.setValue("application/x-www-form-urlencoded",forHTTPHeaderField:"Content-Type")
            } else { request.httpBody = try JSONSerialization.data(withJSONObject:body); request.setValue("application/json",forHTTPHeaderField:"Content-Type") }
        }
        if let bearer { request.setValue("Bearer \(bearer)",forHTTPHeaderField:"Authorization") }
        let (data,response) = try await session.data(for:request)
        guard let response = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        guard (200..<300).contains(response.statusCode) else { throw WireClientError("HTTP \(response.statusCode) — check Firebase credentials, email/password provider and owner-only Firestore rules") }
        return data
    }
}

struct CloudBackupView: View {
    @StateObject private var cloud = CloudBackupClient()
    @Environment(\.modelContext) private var context
    @State private var email = ""
    @State private var password = ""
    @State private var pending:LocalBackup?
    @State private var confirm = false
    @State private var uploading = false
    var body: some View {
        Form {
            Section("Your Firebase project") {
                TextField("Project ID",text:$cloud.project).textInputAutocapitalization(.never).autocorrectionDisabled().disabled(cloud.signedIn)
                TextField("Public Web API key",text:$cloud.apiKey).textInputAutocapitalization(.never).autocorrectionDisabled().disabled(cloud.signedIn)
                Text("Use your existing Firebase project. This uses Firebase end-user authentication and your owner-only Firestore rules; no service-account key is needed.").font(.caption)
            }
            if cloud.signedIn {
                Section("Cloud backup") {
                    Button("Upload local backup") { uploading = true }.disabled(cloud.busy)
                    Button("Download and preview cloud backup") {
                        Task {
                            do { pending = try await cloud.download(); confirm = true }
                            catch { cloud.status = error.localizedDescription }
                        }
                    }.disabled(cloud.busy)
                    Text("Explicit iOS backup snapshots, not automatic Android collection sync. Local files support larger backups. Upload may incur your Firebase storage/write charges.").font(.caption).foregroundStyle(.secondary)
                    Button("Sign out",role:.destructive) { cloud.signOut() }.disabled(cloud.busy)
                }
            } else {
                Section("Account") {
                    TextField("Email",text:$email).keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("Password",text:$password)
                    Button("Sign in") { Task { await cloud.signIn(email:email,password:password); password = "" } }.disabled(cloud.busy)
                    Button("Create account") { Task { await cloud.signIn(email:email,password:password,create:true); password = "" } }.disabled(cloud.busy)
                    Button("Reset password") { Task { await cloud.resetPassword(email:email) } }.disabled(email.isEmpty)
                }
            }
            if cloud.busy { ProgressView() }
            if !cloud.status.isEmpty { Text(cloud.status).font(.footnote).textSelection(.enabled) }
        }.navigationTitle("Cloud backup")
            .confirmationDialog("Upload your garage, attachments, routes and rides to your Firebase account?",isPresented:$uploading,titleVisibility:.visible) {
                Button("Upload backup") {
                    do { try context.save(); let backup = try LocalBackup.capture(context); Task { await cloud.upload(backup) } }
                    catch { cloud.status = error.localizedDescription }
                }
            }
            .confirmationDialog("Import \(pending?.rows.count ?? 0) cloud backup records?",isPresented:$confirm,titleVisibility:.visible) {
                Button("Import missing records") {
                    do { if let pending { cloud.status = "Imported \(try pending.restore(into:context.container)) new records" } }
                    catch { cloud.status = error.localizedDescription }; pending = nil
                }
            }
    }
}
