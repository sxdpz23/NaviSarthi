import SwiftUI
import MapKit
import SwiftData
import UniformTypeIdentifiers

struct NavView: View {
    @EnvironmentObject private var nav: NavigationSession
    @EnvironmentObject private var settings: Settings
    @Environment(\.modelContext) private var context
    @Query(sort:\SavedDestination.title) private var saved: [SavedDestination]
    @Query(sort:\StoredRoute.created,order:.reverse) private var storedRoutes: [StoredRoute]
    @State private var query = ""
    @State private var showSaved = false
    @State private var satellite = false
    @State private var importing = false
    var body: some View {
        ZStack(alignment:.top) {
            if !nav.active || nav.phoneMapVisible {
                Map(position:$nav.camera) {
                    UserAnnotation()
                    if let route = nav.route {
                        MapPolyline(route.polyline).stroke(nav.routeColor,lineWidth:7)
                        if settings.traffic { ForEach(route.trafficStrokes) { stroke in MapPolyline(coordinates:stroke.points).stroke(stroke.color,lineWidth:7) } }
                    }
                    if let destination = nav.destination { Marker(destination.name ?? "Destination",coordinate:destination.placemark.coordinate) }
                }
                .mapStyle(satellite ? .imagery : .standard(elevation:.flat,showsTraffic:settings.traffic))
                .mapControls { MapCompass(); MapScaleView() }
                .ignoresSafeArea(edges:.top)
            } else {
                Color(.systemBackground).ignoresSafeArea()
                VStack(spacing:20) {
                    Image(systemName:"location.north.circle").font(.system(size:72)).foregroundStyle(.blue)
                    Text("Navigation on \(settings.target.rawValue)").font(.title2.bold())
                    Text(nav.instruction).font(.title3).multilineTextAlignment(.center)
                    Button("View phone map temporarily") { nav.phoneMapVisible = true }
                    Text("Dash video currently requires the app in the foreground.").font(.footnote).foregroundStyle(.secondary)
                }.padding(32).frame(maxHeight:.infinity)
            }
            if !nav.active {
                VStack(spacing:10) {
                    HStack {
                        Image(systemName:"magnifyingglass").foregroundStyle(.secondary)
                        TextField("Search places or paste coordinates",text:$query).submitLabel(.search)
                            .onSubmit { search() }
                        if nav.busy { ProgressView() }
                        if !query.isEmpty { Button { query = ""; nav.results = [] } label: { Image(systemName:"xmark.circle.fill") } }
                    }.glassPanel()
                    HStack {
                        Button("Saved Destinations",systemImage:"bookmark") { showSaved = true }
                        Menu {
                            Button("Import GPX track",systemImage:"square.and.arrow.down") { importing = true }
                            if nav.route != nil { Button("Save route for offline guidance") { do { try nav.saveRoute(context) } catch { nav.error = error.localizedDescription } } }
                        } label: { Image(systemName:"ellipsis.circle") }.accessibilityLabel("Route files")
                        Spacer()
                        Button { satellite.toggle() } label: { Image(systemName:"square.3.layers.3d") }.accessibilityLabel("Toggle satellite map")
                        Button { nav.camera = .userLocation(fallback:.automatic); nav.requestLocation() } label: { Image(systemName:"location.fill") }.accessibilityLabel("My location")
                    }.glassPanel()
                    if !nav.results.isEmpty {
                        ScrollView {
                            VStack(alignment:.leading,spacing:0) {
                                ForEach(Array(nav.results.enumerated()),id:\.offset) { _,item in
                                    HStack { Button { Task { await nav.plan(to:item) } } label: {
                                        VStack(alignment:.leading,spacing:4) {
                                            Text(item.name ?? "Place").foregroundStyle(.primary)
                                            Text(item.placemark.title ?? "").font(.caption).foregroundStyle(.secondary).lineLimit(2)
                                        }.frame(maxWidth:.infinity,alignment:.leading).padding(.vertical,12)
                                    }
                                    Button("Stop",systemImage:"plus.circle") { if nav.waypoints.count < 23 { nav.waypoints.append(item) } }.labelStyle(.iconOnly).accessibilityLabel("Add \(item.name ?? "place") as a stop")
                                    }
                                    Divider()
                                }
                            }
                        }.frame(maxHeight:300).glassPanel()
                    }
                    if !nav.waypoints.isEmpty {
                        VStack(alignment:.leading) {
                            Text("Stops before destination").font(.caption).foregroundStyle(.secondary)
                            ForEach(Array(nav.waypoints.enumerated()),id:\.offset) { index,item in
                                HStack { Text("\(index + 1). \(item.name ?? "Stop")"); Spacer(); Button("Remove",systemImage:"xmark") { nav.waypoints.remove(at:index) }.labelStyle(.iconOnly) }
                            }
                        }.glassPanel()
                    }
                }.padding(.horizontal,16).padding(.top,8)
            }
        }
        .safeAreaInset(edge:.bottom,spacing:0) {
            if let route = nav.route {
                VStack(alignment:.leading,spacing:12) {
                    if nav.active {
                        Text(nav.instruction).font(.headline)
                        HStack { Text(settings.distance(nav.turnDistance)); Spacer(); Text("\(nav.eta > 0 ? "\(Int(nav.eta / 60)) min · " : "")\(settings.distance(nav.remaining))") }
                            .font(.subheadline).foregroundStyle(.secondary)
                        HStack {
                            if nav.phoneMapVisible { Button("Return to console view") { nav.phoneMapVisible = false } }
                            Button(nav.followPerspective ? "Top-down view" : "Perspective view") { nav.followPerspective.toggle() }
                            Spacer(); Button("End navigation",role:.destructive) { nav.stop(context:context) }
                        }
                    } else {
                        Text(nav.destination?.name ?? "Destination").font(.headline)
                        if nav.routes.count > 1 {
                            Picker("Route",selection:$nav.selectedRoute) {
                                ForEach(Array(nav.routes.enumerated()),id:\.offset) { index,route in Text("\(Int(route.expectedTravelTime / 60)) min").tag(index) }
                            }.pickerStyle(.segmented)
                        }
                        Text("\(settings.distance(route.distance)) · \(route.source)\(route.expectedTravelTime > 0 ? " · \(Int(route.expectedTravelTime / 60)) min" : " · No turn-by-turn directions")")
                            .font(.subheadline).foregroundStyle(.secondary)
                        HStack {
                            Button("Save",systemImage:"bookmark") { saveDestination() }
                            Spacer()
                            Button("Start navigation",systemImage:"location.north.fill") { nav.start() }.buttonStyle(.borderedProminent)
                        }
                    }
                }.glassPanel().padding(.horizontal,16).padding(.bottom,4)
            }
        }
        .sheet(isPresented:$showSaved) {
            NavigationStack {
                List {
                    if saved.isEmpty { ContentUnavailableView("No saved destinations",systemImage:"bookmark",description:Text("Find a place and tap Save.")) }
                    Section("Places") { ForEach(saved) { place in
                        Button(place.title) {
                            showSaved = false
                            let item = MKMapItem(placemark:MKPlacemark(coordinate:place.coordinate)); item.name = place.title
                            Task { await nav.plan(to:item) }
                        }
                    }.onDelete { indexes in
                        for index in indexes { context.delete(saved[index]) }
                        do { try context.save() } catch { nav.error = error.localizedDescription }
                    } }
                    Section("Offline guidance routes") {
                        ForEach(storedRoutes) { stored in
                            Button(stored.title) {
                                do { try nav.load(JSONDecoder().decode(JourneyRoute.self,from:stored.payload)); showSaved = false }
                                catch { nav.error = error.localizedDescription }
                            }
                        }.onDelete { indexes in for index in indexes { context.delete(storedRoutes[index]) }; do { try context.save() } catch { nav.error = error.localizedDescription } }
                        Text("Stored geometry and instructions work without a route request. Apple basemap tiles and off-route recalculation still require connectivity.").font(.caption).foregroundStyle(.secondary)
                    }
                }.navigationTitle("Saved Destinations")
                    .toolbar { Button("Done") { showSaved = false } }
            }.preferredColorScheme(.dark)
        }
        .fileImporter(isPresented:$importing,allowedContentTypes:[UTType(filenameExtension:"gpx") ?? .xml,.xml]) { result in
            do {
                let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys:[.fileSizeKey]).fileSize ?? 0
                guard size <= 20_000_000 else { throw WireClientError("GPX files must be under 20 MB") }
                try nav.importGPX(Data(contentsOf:url),title:url.deletingPathExtension().lastPathComponent)
            } catch { nav.error = error.localizedDescription }
        }
    }
    private func search() {
        if query.contains(","), let url = URL(string:"navisarthi://nav?q=\(query.addingPercentEncoding(withAllowedCharacters:.urlQueryAllowed) ?? "")") { nav.open(url) }
        else { Task { await nav.searchPlaces(query) } }
    }
    private func saveDestination() {
        guard let item = nav.destination else { return }
        if saved.contains(where:{ abs($0.latitude - item.placemark.coordinate.latitude) < 0.00001 && abs($0.longitude - item.placemark.coordinate.longitude) < 0.00001 }) { return }
        context.insert(SavedDestination(title:item.name ?? "Destination",coordinate:item.placemark.coordinate))
        do { try context.save() } catch { nav.error = error.localizedDescription }
    }
}
