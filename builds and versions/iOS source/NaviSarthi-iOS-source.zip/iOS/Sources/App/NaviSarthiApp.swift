import SwiftUI
import SwiftData

@main @MainActor struct NaviSarthiApp: App {
    @StateObject private var settings = Settings()
    @StateObject private var nav = NavigationSession()
    @StateObject private var dash = DashConnection()
    @StateObject private var pod = PodConnection()
    @StateObject private var comms = CommsClient()
    private let storage: Result<ModelContainer,Error> = Result { try AppStorageSchema.container() }
    var body: some Scene {
        WindowGroup {
            switch storage {
            case .success(let container):
                RootView().modelContainer(container)
                    .environmentObject(settings).environmentObject(nav).environmentObject(dash)
                    .environmentObject(pod).environmentObject(comms)
                    .preferredColorScheme(.dark).tint(.blue)
            case .failure(let error):
                ContentUnavailableView("Storage could not open",systemImage:"externaldrive.badge.exclamationmark",description:Text(error.localizedDescription))
            }
        }
    }
}

enum AppTab: String, CaseIterable {
    case console = "Console", nav = "Nav", garage = "Garage", comms = "Comms", settings = "Settings"
    var icon: String {
        switch self {
        case .console: return "speedometer"
        case .nav: return "location.north.line"
        case .garage: return "wrench.and.screwdriver"
        case .comms: return "person.2.wave.2"
        case .settings: return "gearshape"
        }
    }
}

struct GlassPanel: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(16).background(.ultraThinMaterial,in:RoundedRectangle(cornerRadius:24))
            .overlay(RoundedRectangle(cornerRadius:24).stroke(.white.opacity(0.12),lineWidth:0.5))
    }
}
extension View { func glassPanel() -> some View { modifier(GlassPanel()) } }

struct RootView: View {
    @EnvironmentObject private var settings: Settings
    @EnvironmentObject private var nav: NavigationSession
    @EnvironmentObject private var dash: DashConnection
    @EnvironmentObject private var pod: PodConnection
    @EnvironmentObject private var comms: CommsClient
    @Environment(\.scenePhase) private var scenePhase
    @State private var tab = AppTab.console
    var body: some View {
        Group {
            switch tab {
            case .console: ConsoleView()
            case .nav: NavView()
            case .garage: GarageView()
            case .comms: CommsView()
            case .settings: SettingsView()
            }
        }
        .safeAreaInset(edge:.bottom,spacing:8) {
            HStack(spacing:0) {
                ForEach(AppTab.allCases,id:\.self) { item in
                    Button {
                        tab = item
                        if item != .nav { nav.phoneMapVisible = false }
                    } label: {
                        VStack(spacing:5) {
                            Image(systemName:item.icon).font(.system(size:20))
                            Text(item == .console ? settings.target.rawValue : item.rawValue).font(.caption2)
                        }.foregroundStyle(tab == item ? Color.blue : Color.secondary)
                            .frame(maxWidth:.infinity).padding(.vertical,6).contentShape(Rectangle())
                    }.buttonStyle(.plain).accessibilityAddTraits(tab == item ? .isSelected : [])
                }
            }.glassPanel().padding(.horizontal,16)
        }
        .task {
            nav.voiceEnabled = settings.voice
            nav.routeColor = settings.routeColor
            nav.trafficEnabled = settings.traffic
            nav.selectedVehicleID = UUID(uuidString:settings.vehicleID)
            nav.onGuidance = { _,turn,remaining in
                if settings.target == .pod { pod.guidance(turn:turn,remaining:remaining,glyph:nav.podGlyph) }
            }
            nav.onStop = { dash.stopStream() }
            nav.onFix = { fix in Task { await comms.publish(fix) } }
            nav.requestLocation()
        }
        .task { await comms.run() }
        .onChange(of:comms.sharing) { _,sharing in nav.setGroupSharing(sharing) }
        .onChange(of:settings.voice) { _,value in nav.voiceEnabled = value }
        .onChange(of:settings.routeColour) { _,_ in nav.routeColor = settings.routeColor }
        .onChange(of:settings.traffic) { _,value in nav.trafficEnabled = value }
        .onChange(of:settings.vehicleID) { _,value in nav.selectedVehicleID = UUID(uuidString:value) }
        .onChange(of:nav.active) { _,active in
            if active && settings.target == .dash { dash.start(nav) }
        }
        .onChange(of:dash.authenticated) { _,connected in
            if connected && nav.active && settings.target == .dash { dash.start(nav) }
        }
        .onChange(of:settings.target) { _,target in
            dash.stopStream()
            if nav.active && target == .dash { dash.start(nav) }
        }
        .onChange(of:scenePhase) { _,phase in
            // Snapshot rendering is a foreground-only validation path.
            if phase == .background { dash.stopStream() }
            if phase == .active && nav.active && settings.target == .dash { dash.start(nav) }
        }
        .onOpenURL { url in tab = .nav; nav.open(url) }
        .alert("Navigation",isPresented:Binding(get:{ nav.error != nil },set:{ if !$0 { nav.error = nil } })) {
            Button("OK",role:.cancel) { nav.error = nil }
        } message: { Text(nav.error ?? "") }
    }
}
