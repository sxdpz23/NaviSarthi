import SwiftUI
import UIKit

struct ConsoleView: View {
    @EnvironmentObject private var settings: Settings
    @EnvironmentObject private var nav: NavigationSession
    @EnvironmentObject private var dash: DashConnection
    @EnvironmentObject private var pod: PodConnection
    @State private var ssid = UserDefaults.standard.string(forKey:"dashSSID") ?? ""
    @State private var password = "12345678"
    @State private var pin = ""
    @State private var connecting = false
    @State private var holdScreen = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing:24) {
                    ZStack {
                        Circle().fill(Color(.secondarySystemBackground)).overlay(Circle().stroke(Color.blue.opacity(0.4),lineWidth:2))
                        VStack(spacing:12) {
                            Image(systemName:nav.active ? "location.north.fill" : "speedometer").font(.system(size:42)).foregroundStyle(.blue)
                            Text(nav.active ? nav.instruction : "Ready when you are").font(.title3.bold()).multilineTextAlignment(.center).lineLimit(3)
                            Text(nav.active ? settings.distance(nav.turnDistance) : settings.target.rawValue).foregroundStyle(.secondary)
                        }.padding(32)
                    }.frame(width:280,height:280)
                    VStack(alignment:.leading,spacing:14) {
                        Label(settings.target == .dash ? dash.status : pod.status,systemImage:"antenna.radiowaves.left.and.right")
                        if settings.target == .dash {
                            TextField("Dash Wi-Fi name (RE_…)",text:$ssid).textInputAutocapitalization(.never).autocorrectionDisabled()
                            SecureField("Wi-Fi password",text:$password)
                            HStack {
                                Button(connecting ? "Joining…" : "Connect") {
                                    connecting = true; UserDefaults.standard.set(ssid,forKey:"dashSSID")
                                    Task { await dash.connect(ssid:ssid,password:password); connecting = false }
                                }.buttonStyle(.borderedProminent).disabled(connecting || dash.authenticated)
                                Button("Disconnect") { dash.disconnect() }.disabled(!dash.authenticated && !connecting)
                            }
                            Button(nav.followPerspective ? "TDV · Top-down view" : "POV · Perspective view") { nav.followPerspective.toggle() }
                            if dash.streaming { Text("\(dash.frames) frames sent").font(.caption.monospacedDigit()) }
                            HStack {
                                Button("Zoom out",systemImage:"minus.magnifyingglass") { dash.zoom = min(10000,dash.zoom * 1.25) }
                                Spacer()
                                Button("Zoom in",systemImage:"plus.magnifyingglass") { dash.zoom = max(200,dash.zoom / 1.25) }
                            }
                            Toggle("Keep phone screen awake",isOn:$holdScreen)
                                .onChange(of:holdScreen) { _,value in UIApplication.shared.isIdleTimerDisabled = value }
                            Text("Foreground streaming is experimental. Locking or backgrounding the app stops video. Validate on your bike before relying on it.")
                                .font(.footnote).foregroundStyle(.secondary)
                        } else {
                            HStack {
                                Button("Connect Pod") { pod.connect() }.buttonStyle(.borderedProminent).disabled(pod.ready)
                                Button("Disconnect") { pod.disconnect() }
                            }
                            if pod.needsPIN {
                                TextField("Six-digit PIN",text:$pin).keyboardType(.numberPad)
                                Button("Authorize") { pod.authorize(pin) }
                            }
                            if !pod.ready { ForEach(pod.devices) { device in Button("\(device.name) · \(device.rssi) dBm") { pod.choose(device.id) } } }
                            Text("Select a Pod when pairing. Structured-provider turns, distance guidance and bounded reconnect are implemented; hardware validation remains pending.")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }.glassPanel()
                    NavigationLink("Ride history",destination:RidesView()).buttonStyle(.bordered)
                }.padding(20)
            }.navigationTitle(settings.target.rawValue)
        }
    }
}
